
  # Create mobile landing page

  This is a code bundle for Create mobile landing page. The original project is available at https://www.figma.com/design/Yz50RJdB7iieMHQAD0XEmY/Create-mobile-landing-page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  
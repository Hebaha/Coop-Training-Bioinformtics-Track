import { useState } from "react";
import mulhimLogo from "@/imports/Purple_and_White_Illustrated_Biotechnology_Presentation.png";

// ─── Native SVG Icons (No External Dependencies) ───────────────────────────────
interface IconProps {
  size?: number;
  color?: string;
  className?: string;
}

const BaseIcon = ({ size = 18, color = "currentColor", className = "", children }: IconProps & { children: React.ReactNode }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke={color}
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
  >
    {children}
  </svg>
);

const IconDna = (p: IconProps) => <BaseIcon {...p}><path d="m8 8 8 8"/><path d="m9 5 6 6"/><path d="m5 9 6 6"/><path d="M2 15c6.667-6 13.333 0 20-6"/><path d="M2 9c6.667 6 13.333 0 20 6"/></BaseIcon>;
const IconArrowLeft = (p: IconProps) => <BaseIcon {...p}><line x1="19" x2="5" y1="12" y2="12"/><polyline points="12 19 5 12 12 5"/></BaseIcon>;
const IconSparkles = (p: IconProps) => <BaseIcon {...p}><path d="m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3z"/></BaseIcon>;
const IconCheck = (p: IconProps) => <BaseIcon {...p}><polyline points="20 6 9 17 4 12"/></BaseIcon>;
const IconChevronRight = (p: IconProps) => <BaseIcon {...p}><polyline points="9 18 15 12 9 6"/></BaseIcon>;
const IconFlask = (p: IconProps) => <BaseIcon {...p}><path d="M10 2v7.31L4.12 19.1A2 2 0 0 0 5.8 22h12.4a2 2 0 0 0 1.68-2.9L14 9.31V2"/><path d="M8.5 2h7"/><path d="M6.5 16h11"/></BaseIcon>;
const IconClipboard = (p: IconProps) => <BaseIcon {...p}><rect width="8" height="4" x="8" y="2" rx="1" ry="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/></BaseIcon>;
const IconActivity = (p: IconProps) => <BaseIcon {...p}><path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.48 12H2"/></BaseIcon>;
const IconTarget = (p: IconProps) => <BaseIcon {...p}><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></BaseIcon>;
const IconDumbbell = (p: IconProps) => <BaseIcon {...p}><path d="m6.5 6.5 11 11"/><path d="m21 21-1-1a2 2 0 0 0-2.83 0l-.88.88a2 2 0 0 0 0 2.83l1 1a2 2 0 0 0 2.83 0l.88-.88a2 2 0 0 0 0-2.83Z"/><path d="m3 3 1 1a2 2 0 0 0 2.83 0l.88-.88a2 2 0 0 0 0-2.83l-1-1a2 2 0 0 0-2.83 0l-.88.88a2 2 0 0 0 0 2.83Z"/></BaseIcon>;
const IconMoon = (p: IconProps) => <BaseIcon {...p}><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/></BaseIcon>;
const IconApple = (p: IconProps) => <BaseIcon {...p}><path d="M12 20.94c1.5 0 2.75-.81 4-1.21.9-.3 1.8-.6 2.7-.6 1.4 0 2.6.6 3.3 1.8-2.6 1.5-3.3 4.8-1.5 7.4.9 1.3 2.1 2.3 3.5 2.8-.8 2.2-1.9 4.3-3.4 6.2-1.3 1.7-2.7 3.3-4.6 3.3-1.9 0-2.5-1.1-4.7-1.1-2.2 0-2.9 1.1-4.7 1.1-1.9 0-3.3-1.6-4.6-3.3C3.5 23.5 2 19 2 14.5c0-4.8 3.1-7.4 6.1-7.4 1.9 0 3.3 1.2 4.4 1.2.9 0 2.2-1.2 3.9-1.2 1.4 0 3.1.6 4.1 1.8-3.4 1.8-2.8 6.4.5 8.1-.8 1.9-1.9 3.7-3.4 5.3"/></BaseIcon>;
const IconBrain = (p: IconProps) => <BaseIcon {...p}><path d="M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z"/><path d="M12 5a3 3 0 1 1 5.997.125 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z"/></BaseIcon>;
const IconHeartPulse = (p: IconProps) => <BaseIcon {...p}><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/><path d="M3.22 12H9.5l.5-1 2 4.5 2-7 1.5 3.5h4.27"/></BaseIcon>;
const IconHeart = (p: IconProps) => <BaseIcon {...p}><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></BaseIcon>;
const IconDroplet = (p: IconProps) => <BaseIcon {...p}><path d="M12 22a7 7 0 0 0 7-7c0-2-1-3.9-3-6-1.5-1.5-3-3.5-4-5-1 1.5-2.5 3.5-4 5-2 2.1-3 4-3 6a7 7 0 0 0 7 7Z"/></BaseIcon>;
const IconMenu = (p: IconProps) => <BaseIcon {...p}><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/></BaseIcon>;
const IconClose = (p: IconProps) => <BaseIcon {...p}><line x1="18" x2="6" y1="6" y2="18"/><line x1="6" x2="18" y1="6" y2="18"/></BaseIcon>;

// Social Icons
const IconX = (p: IconProps) => (
  <BaseIcon {...p}>
    <path d="M4 4l11.733 16h4.267l-11.733-16z" />
    <path d="M4 20l6.768-6.768m3.464-3.464L20 4" />
  </BaseIcon> 
);
const IconInstagram = (p: IconProps) => (
  <BaseIcon {...p}>
    <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
    <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
  </BaseIcon>
);
const IconWhatsapp = (p: IconProps) => (
  <BaseIcon {...p}>
    <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" />
  </BaseIcon>
);

// ─── Global Styles Definition ──────────────────────────────────────────────────
const GLOBAL_STYLES = `
  .no-scrollbar::-webkit-scrollbar {
    display: none;
  }
  .no-scrollbar {
    -ms-overflow-style: none;
    scrollbar-width: none;
  }
`;

// ─── Types ────────────────────────────────────────────────────────────────────
type Screen = "landing" | "details" | "checkout" | "confirmation" | "questionnaire" | "appdownload";

interface PackageItem {
  id: number;
  badge: string | null;
  heroImage: string;
  tag: string;
  title: string;
  goal: string;
  description: string;
  whatYouDiscover: string[];
  whatYouReceive: string[];
  isEnterprise?: boolean;
  fullFeaturesList?: string[];
}

// ─── Packages Data ────────────────────────────────────────────────────────────
const PACKAGES: PackageItem[] = [
  {
    id: 1,
    badge: "POPULAR",
    heroImage: "https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=600&auto=format&fit=crop&q=80",
    tag: "Athletes Package",
    title: "Athletes Peak Performance & Recovery Blueprint",
    goal: "To stop trial-and-error in your fitness journey by revealing how your body is built to train, fuel, and recover for safe peak performance.",
    description: "Breaks down whether your muscles are built for explosive speed or long-term endurance, your cardio handling capacity, joint protection boundaries, and post-exercise recovery.",
    whatYouDiscover: [
      "Muscle fiber distribution (Explosive Power vs. Endurance)",
      "Cardiorespiratory fitness and metabolic fat/sugar burning zones",
      "Ligament strength, tendon recovery speed, and joint protection",
      "Central nervous system stress resilience and sleep architecture",
      "Post-exercise muscle glycogen replenishment speed"
    ],
    whatYouReceive: [
      "Customized athletic training and workout schedule",
      "Targeted performance fueling and hydration plan",
      "Injury prevention, warm-up, and joint mobility protocol",
      "Sleep optimization and pre-competition recovery guide",
      "AI-powered continuous physical adaptation coaching"
    ],
    fullFeaturesList: [
      "100% fully customized athletic training program",
      "Integrated performance plan to achieve peak athletic goals",
      "Discover muscle fiber speed and explosive power potential",
      "Cardiorespiratory fitness and aerobic conditioning zones",
      "Nutritional recommendations supporting athletic performance",
      "Musculoskeletal injury mitigation and joint mobility protocol",
      "Autonomic nervous system recovery and sleep tracking",
      "Continuous performance data analysis to improve results"
    ],
  },
  {
    id: 2,
    badge: "RECOMMENDED",
    heroImage: "https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=600&auto=format&fit=crop&q=80",
    tag: "Men's Package",
    title: "Men's Vitality, Performance & Healthy Aging",
    goal: "To help you unlock your full health and performance potential by understanding your body's natural functions with personalized guidance.",
    description: "Identifies your natural metabolism, muscle performance potential, hormonal balance, daily recovery speed, and cellular longevity factors.",
    whatYouDiscover: [
      "Metabolic efficiency and nutrient processing profile",
      "Muscle performance, strength capacity, and recovery ability",
      "Hormonal health, energy regulation, and vitality markers",
      "Sleep quality profile, circadian rhythm, and stress resilience",
      "Biological aging indicators and cellular wellness"
    ],
    whatYouReceive: [
      "AI-powered metabolic and heart health report",
      "Personalized nutrition plan and calorie/macro distribution",
      "Custom training and muscle performance plan",
      "Sleep optimization and stress management guide",
      "Long-term vitality and healthy aging recommendations"
    ],
    fullFeaturesList: [
      "Custom metabolic nutrition report tailored to your biology",
      "Recommendations for best foods and supplements for your body",
      "Foods to avoid and targeted allergen management",
      "Ideal distribution of calories and macronutrients",
      "Analysis of physical endurance and muscle strength capacity",
      "Recovery speed and post-exercise inflammation assessment",
      "Comprehensive report on sleep quality and stress resilience",
      "Hormonal health balance and healthy longevity indicators"
    ],
  },
  {
    id: 3,
    badge: null,
    heroImage: "https://images.unsplash.com/photo-1518611012118-696072aa579a?w=600&auto=format&fit=crop&q=80",
    tag: "Women's Package",
    title: "Women's Balance, Hormonal Health & Beauty",
    goal: "To help you understand your body deeply, providing tailored nutrition, fitness, hormonal, and beauty guidance for every stage of life.",
    description: "Provides comprehensive biological insights into your metabolism, training response, sleep architecture, hormonal balance, and skin/hair vitality.",
    whatYouDiscover: [
      "Metabolic profile and natural response to carbs and fats",
      "Hormonal balance, estrogen metabolism, and thyroid insights",
      "Skin health profile, collagen maintenance, and UV sensitivity",
      "Natural sleep rhythm, stress recovery, and daily energy",
      "Fitness response, muscle tone potential, and injury protection"
    ],
    whatYouReceive: [
      "AI-powered hormonal and metabolic health report",
      "Personalized nutrition and dietary guidance",
      "Tailored workout and physical recovery plan",
      "Customized skincare and hair wellness recommendations",
      "Continuous wellness monitoring adapted to your life stages"
    ],
    fullFeaturesList: [
      "Comprehensive skin and hair analysis from biological insights",
      "Skin hydration level and natural collagen maintenance",
      "Skin sun sensitivity and environmental stress analysis",
      "Cellular vitality and biological aging indicators",
      "Hormonal balance support across different life stages",
      "Ideal distribution of calories, healthy fats, and nutrients",
      "Personalized training, muscle tone, and recovery plan",
      "Targeted recommendations for daily wellness and vitality"
    ],
  },
  {
    id: 4,
    badge: null,
    heroImage: "https://images.unsplash.com/photo-1502086223501-7ea6ecd79368?w=600&auto=format&fit=crop&q=80",
    tag: "Children's Package",
    title: "Children's Growth, Nutrition & Milestone Blueprint",
    goal: "To take the guessing out of parenting so you can confidently support your child's unique growth, digestive comfort, and restful development.",
    description: "Helps parents understand their child's natural height pathways, bone density building, food sensitivities (lactose/gluten), and bedtime calming rhythms.",
    whatYouDiscover: [
      "Height velocity pathways and structural bone building potential",
      "Digestive comfort and sensitivities (lactose, gluten processing)",
      "Essential vitamin and mineral absorption levels (Iron, Zinc, Vit D)",
      "Natural sleep quality and bedtime stress relaxation capacity",
      "Metabolic response to energy and early cardiovascular baselines"
    ],
    whatYouReceive: [
      "Pediatric growth and development roadmap",
      "Kid-friendly balanced meal and nutrition plan",
      "Digestive comfort guide and symptom logs",
      "Age-appropriate safe play, posture, and exercise guide",
      "AI-supported milestone and growth tracking"
    ],
    fullFeaturesList: [
      "Pediatric height velocity and natural growth pathways",
      "Bone density building and skeletal structural health",
      "Food sensitivities analysis (lactose, gluten, and sugar processing)",
      "Essential vitamin and mineral absorption metrics (Iron, Zinc, Vit D)",
      "Bedtime routine optimization and restful sleep planning",
      "Digestive comfort guide and symptom logging support",
      "Age-appropriate safe exercise, posture, and play guidelines",
      "Continuous pediatric milestone tracking with Mulhim AI"
    ],
  },
  {
    id: 5,
    badge: "ENTERPRISE",
    heroImage: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=600&auto=format&fit=crop&q=80",
    tag: "Enterprise Package",
    title: "Solutions for Enterprise & Sports Organizations",
    goal: "To enable sports clubs, academies, universities, and enterprise teams to manage large-scale biological wellness and performance pipelines.",
    description: "Equips organizations with centralized roster management, team-wide biological risk screening, load optimization protocols, and custom institutional branding.",
    whatYouDiscover: [
      "Team-wide physiological readiness and recovery telemetry",
      "Musculoskeletal injury risk distribution across player rosters",
      "Nutritional and metabolic optimization for group performance",
      "Stress adaptation and travel fatigue management protocols",
      "Long-term athlete development and performance trend curves"
    ],
    whatYouReceive: [
      "Centralized organizational dashboard & coach analytics",
      "Multi-athlete biological reports & comparative insights",
      "Custom white-label branding & team workflow integration",
      "Dedicated medical & bioinformatics specialist advisory",
      "Enterprise-grade API access & continuous AI monitoring"
    ],
    fullFeaturesList: [
      "Centralized organization dashboard for multi-athlete management",
      "Roster biological health reports and risk stratification",
      "Team-wide workout, hydration, and nutritional planning",
      "Custom white-label branding for sports academies and clubs",
      "Automated coach alert system for overtraining and fatigue",
      "Enterprise-grade secure API integration and EHR compatibility",
      "Dedicated bioinformatics advisory and clinical onboarding",
      "Long-term athlete performance analytics and KPI reporting"
    ],
    isEnterprise: true,
  },
];

// ─── Status Bar ───────────────────────────────────────────────────────────────
function StatusBar() {
  return (
    <div className="flex justify-between items-center px-8 pt-3 pb-2 bg-white shrink-0 select-none z-30">
      <span className="text-[12px] font-bold text-slate-800" style={{ fontFamily: "'Inter', sans-serif" }}>
        9:41
      </span>
      <div className="w-24 h-5 rounded-full absolute left-1/2 -translate-x-1/2 top-0 bg-[#0F172A]" />
      <div className="flex items-center gap-1.5 text-slate-800">
        <IconActivity size={12} />
        <span className="text-[11px] font-bold">100%</span>
      </div>
    </div>
  );
}

// ─── 1. Bioinformatics Landing Page ───────────────────────────────────────────
function BioinformaticsLandingScreen({
  onSelectPackage,
}: {
  onSelectPackage: (pkg: PackageItem) => void;
}) {
  const [menuOpen, setMenuOpen] = useState(false);

  const navMenuItems = [
    "Products",
    "Pricing",
    "Docs",
    "Support",
    "About",
    "Contact",
    "Privacy",
    "Terms",
  ];

  return (
    <div className="flex flex-col h-full overflow-hidden bg-white relative">
      {menuOpen && (
        <div className="absolute inset-0 z-50 bg-white flex flex-col justify-between px-7 pt-4 pb-8 animate-fadeIn">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <img src={mulhimLogo} alt="Mulhim logo" className="w-10 h-10 object-contain" />
                <span className="text-[20px] font-black tracking-tight text-[#0F172A]">Mulhim</span>
              </div>
              <button
                onClick={() => setMenuOpen(false)}
                className="w-10 h-10 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-center text-slate-700 hover:bg-slate-100 transition-colors"
              >
                <IconClose size={18} />
              </button>
            </div>

            <nav className="flex flex-col pt-3 space-y-4">
              {navMenuItems.map((item) => (
                <button
                  key={item}
                  onClick={() => setMenuOpen(false)}
                  className="text-left text-[17px] font-semibold text-slate-900 hover:text-[#0F5B4E] transition-colors py-0.5"
                >
                  {item}
                </button>
              ))}
            </nav>
          </div>

          <div className="space-y-4 pt-4 border-t border-slate-100">
            <button
              onClick={() => setMenuOpen(false)}
              className="w-full text-center text-[15px] font-bold text-slate-900 hover:text-[#0F5B4E] py-1"
            >
              Sign In
            </button>
            <a
              href="#packages-section"
              onClick={() => setMenuOpen(false)}
              className="w-full py-4 rounded-2xl bg-[#094848] text-white text-[15px] font-bold flex items-center justify-center active:scale-95 transition-all shadow-md shadow-[#094848]/20"
            >
              Get Started
            </a>
          </div>
        </div>
      )}

      <header className="flex items-center justify-between px-6 pt-3 pb-3 shrink-0 bg-white border-b border-slate-100">
        <div className="flex items-center gap-2">
          <img src={mulhimLogo} alt="Mulhim logo" className="w-9 h-9 object-contain" />
          <span className="text-[20px] font-black tracking-tight text-[#0F172A]">Mulhim</span>
        </div>
        <button
          onClick={() => setMenuOpen(true)}
          className="p-2 rounded-xl text-slate-700 hover:bg-slate-50 transition-colors"
        >
          <IconMenu size={20} />
        </button>
      </header>

      <div className="flex-1 overflow-y-auto px-6 pb-10 space-y-10">
        {/* 1. Hero Section */}
        <section className="pt-6 text-left space-y-4">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#E6F7F2] border border-[#A7F3D0] text-[#0F5B4E] text-[11px] font-bold">
            <IconSparkles size={13} />
            <span>Bioinformatics Layer</span>
          </div>

          <h1 className="text-[36px] font-extrabold tracking-tight text-[#0F172A] leading-[1.15]">
            Health guidance <br />
            <span className="bg-gradient-to-r from-[#133E3E] via-[#10B981] to-[#133E3E] bg-clip-text text-transparent">
              shaped by your biology
            </span>
          </h1>

          <p className="text-[14px] text-slate-600 leading-relaxed font-normal max-w-[650px]">
            Mulhim combines biological insights, lab biomarkers, and your day-to-day lifestyle to deliver 100% personalized health, athletic, and nutrition plans.
          </p>

          <div className="pt-1 max-w-[280px]">
            <a
              href="#packages-section"
              className="w-full py-4 rounded-2xl bg-[#133E3E] text-white text-[14px] font-bold flex items-center justify-center gap-2 shadow-lg shadow-[#133E3E]/20 active:scale-95 transition-transform"
            >
              Explore Bio Packages ↓
            </a>
          </div>
        </section>

        {/* 2. What Bioinformatics with Mulhim means (All 5 in 1 Single Horizontal Row) */}
        <section className="space-y-4 pt-2">
          <div>
            <h2 className="text-[22px] font-extrabold text-[#0F172A]">What Bioinformatics with Mulhim means</h2>
            <p className="text-[13px] text-slate-500 leading-relaxed mt-1">
              Mulhim connects your biological foundation, lab biomarkers, and daily habits so health recommendations reflect who you truly are.
            </p>
          </div>

          <div className="grid grid-cols-5 gap-2.5">
            {[
              { icon: IconDna, title: "Biological Analysis", desc: "Foundational traits" },
              { icon: IconFlask, title: "Lab Biomarkers", desc: "Panels & vitals" },
              { icon: IconClipboard, title: "Phenotype Log", desc: "Physical metrics" },
              { icon: IconActivity, title: "Lifestyle Habit", desc: "Sleep & stress" },
              { icon: IconTarget, title: "User Goals", desc: "Personalized targets" },
            ].map(({ icon: Icon, title, desc }) => (
              <div key={title} className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-1.5 flex flex-col justify-between">
                <div className="w-8 h-8 rounded-xl bg-[#E6F7F2] flex items-center justify-center mb-1">
                  <Icon size={16} color="#0F5B4E" />
                </div>
                <div>
                  <p className="text-[12px] font-bold text-slate-900 leading-snug">{title}</p>
                  <p className="text-[10.5px] text-slate-500 mt-0.5 leading-tight">{desc}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* 3. Biological Packages Section (2 Columns Grid for iPad) */}
        <section id="packages-section" className="space-y-4 pt-1">
          <div>
            <span className="text-[10.5px] font-extrabold uppercase tracking-widest text-[#0F5B4E] bg-[#E6F7F2] px-2.5 py-1 rounded-md">
              Specialized Service Bundles
            </span>
            <h2 className="text-[24px] font-extrabold text-[#0F172A] mt-2">Our Biological Packages</h2>
            <p className="text-[13px] text-slate-500">Comprehensive packages designed for every member of your family and athletic level.</p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {PACKAGES.map((pkg) => (
              <div
                key={pkg.id}
                className={`rounded-3xl bg-white border border-slate-200 overflow-hidden shadow-sm flex flex-col justify-between hover:border-[#133E3E]/40 transition-all ${
                  pkg.isEnterprise ? "col-span-2 md:flex-row" : ""
                }`}
              >
                <div className={`relative w-full overflow-hidden bg-slate-100 ${pkg.isEnterprise ? "md:w-1/2 h-52 md:h-auto" : "h-44"}`}>
                  <img src={pkg.heroImage} alt={pkg.title} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                  {pkg.badge && (
                    <span className="absolute top-3.5 left-3.5 bg-[#133E3E] text-[#A7F3D0] text-[10px] font-extrabold px-3 py-1 rounded-full shadow-md">
                      {pkg.badge}
                    </span>
                  )}
                  <div className="absolute bottom-3 left-4 right-4 text-white">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-[#A7F3D0]">{pkg.tag}</span>
                    <h3 className="text-[16px] font-extrabold leading-tight drop-shadow-sm">{pkg.title}</h3>
                  </div>
                </div>

                <div className={`p-5 flex flex-col justify-between space-y-4 ${pkg.isEnterprise ? "md:w-1/2" : "flex-1"}`}>
                  <p className="text-[12px] text-slate-600 leading-relaxed font-medium line-clamp-3">{pkg.goal}</p>

                  <div className="space-y-2 border-t border-slate-100 pt-3">
                    <p className="text-[11.5px] font-bold text-slate-800">Key Focus Areas:</p>
                    <div className="space-y-1.5">
                      {pkg.whatYouDiscover.slice(0, 3).map((item) => (
                        <div key={item} className="flex items-start gap-2 text-[11px] text-slate-600">
                          <IconCheck size={14} color="#10B981" className="shrink-0 mt-0.5" />
                          <span className="line-clamp-1">{item}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <button
                    onClick={() => onSelectPackage(pkg)}
                    className="w-full py-3 rounded-2xl text-[12.5px] font-bold flex items-center justify-center gap-1.5 bg-[#133E3E] text-white active:scale-[0.98] shadow-md mt-2"
                  >
                    {pkg.isEnterprise ? "View Details & Connect With Us →" : "View Package Details"}
                    {!pkg.isEnterprise && <IconChevronRight size={15} color="#A7F3D0" />}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* 4. 3 Simple Steps */}
        <section className="space-y-4 pt-2">
          <div>
            <span className="text-[10.5px] font-extrabold uppercase tracking-widest text-[#0F5B4E] bg-[#E6F7F2] px-2.5 py-1 rounded-md">
              Testing Journey
            </span>
            <h2 className="text-[22px] font-extrabold text-[#0F172A] mt-2">Simple steps to get your analysis</h2>
            <p className="text-[13px] text-slate-500">Start your biological journey with three simple, comfortable steps.</p>
          </div>

          <div className="grid grid-cols-3 gap-3">
            {[
              {
                step: "1",
                title: "Sample collection at home",
                desc: "Collected comfortably at home! A quick, non-invasive cheek swab sample collected in less than a minute.",
              },
              {
                step: "2",
                title: "Bioinformatics analysis",
                desc: "Advanced processing on your biological sample to analyze metabolic rates and cardiorespiratory baselines.",
              },
              {
                step: "3",
                title: "Report generation & AI plan",
                desc: "We generate customized biological reports and sync real-time adaptive workouts and meal plans directly inside Mulhim.",
              },
            ].map((s) => (
              <div key={s.step} className="p-5 rounded-3xl bg-white border border-slate-200 shadow-sm flex flex-col justify-start gap-3">
                <div className="w-10 h-10 rounded-2xl bg-[#E6F7F2] text-[#0F5B4E] font-extrabold text-sm flex items-center justify-center shrink-0">
                  {s.step}
                </div>
                <div className="space-y-1">
                  <p className="text-[13.5px] font-extrabold text-slate-900">{s.title}</p>
                  <p className="text-[11.5px] text-slate-600 leading-relaxed">{s.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* 5. 5 Health Areas Section */}
        <section className="space-y-4 pt-2">
          <div>
            <h2 className="text-[22px] font-extrabold text-[#0F172A]">Personalized across every health area</h2>
            <p className="text-[13px] text-slate-500">Bioinformatics insights continuously feed into the core modules inside Mulhim.</p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {[
              { icon: IconDumbbell, title: "Exercise", desc: "Training guidance shaped by athletic and recovery traits." },
              { icon: IconMoon, title: "Recovery & Sleep", desc: "Rest and recovery insights informed by your biology." },
              { icon: IconApple, title: "Nutrition", desc: "Dietary guidance built around your metabolism and goals." },
              { icon: IconSparkles, title: "Hair & Skin", desc: "Care guidance informed by cellular vitality and lifestyle." },
              { icon: IconBrain, title: "Mental Wellness", desc: "Focus and stress resilience guidance tailored to your profile." },
            ].map(({ icon: Icon, title, desc }) => (
              <div key={title} className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm flex items-start gap-3.5">
                <div className="w-9 h-9 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-center shrink-0">
                  <Icon size={18} color="#133E3E" />
                </div>
                <div>
                  <p className="text-[13.5px] font-bold text-slate-900">{title}</p>
                  <p className="text-[11.5px] text-slate-500 mt-0.5">{desc}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* 6. Detailed Comparison Matrix (2 Columns Grid for iPad) */}
        <section className="space-y-4 pt-4 border-t border-slate-100">
          <div className="text-center space-y-1">
            <h2 className="text-[24px] font-extrabold text-[#0F172A] tracking-tight">
              Choose your suitable <span className="text-[#0F5B4E]">genetic package</span>
            </h2>
            <p className="text-[13px] text-slate-500 max-w-[400px] mx-auto">
              Explore the package that fits your lifestyle and health goals.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4 pt-2">
            {PACKAGES.map((pkg) => (
              <div
                key={`comparison-${pkg.id}`}
                className={`rounded-3xl bg-white border border-slate-200 shadow-sm overflow-hidden flex flex-col justify-between ${
                  pkg.isEnterprise ? "col-span-2" : ""
                }`}
              >
                <div className="p-5 text-center bg-gradient-to-b from-[#F0FDF4] to-white border-b border-slate-100 space-y-1">
                  <span className="text-[10px] font-extrabold uppercase tracking-widest text-[#0F5B4E] bg-[#E6F7F2] px-3 py-1 rounded-full inline-block mb-1">
                    {pkg.tag}
                  </span>
                  <h3 className="text-[16px] font-black text-[#0F172A] leading-snug">{pkg.title}</h3>
                  <p className="text-[11px] text-slate-500 mt-1 font-medium line-clamp-2">{pkg.goal}</p>
                </div>

                <div className="p-4 flex-1 space-y-2.5">
                  {(pkg.fullFeaturesList || pkg.whatYouDiscover).map((feature, idx) => (
                    <div key={idx} className="flex items-start gap-2 text-[11.5px] text-slate-700 leading-relaxed">
                      <div className="w-4 h-4 rounded-full bg-[#E6F7F2] flex items-center justify-center shrink-0 mt-0.5 border border-[#A7F3D0]">
                        <IconCheck size={11} color="#0F5B4E" />
                      </div>
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>

                <div className="p-4 pt-0">
                  <button
                    onClick={() => onSelectPackage(pkg)}
                    className="w-full py-3.5 rounded-2xl bg-[#133E3E] text-white font-extrabold text-[12.5px] active:scale-95 transition-all shadow-md flex items-center justify-center gap-1.5"
                  >
                    {pkg.isEnterprise ? "Inquire for Enterprise" : "Subscribe now"}
                    <IconChevronRight size={15} color="#A7F3D0" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Footer with Mulhim Logo */}
        <footer className="pt-6 border-t border-slate-200 text-left space-y-6">
          <div className="grid grid-cols-4 gap-6">
            <div className="space-y-2 col-span-1">
              <div className="flex items-center gap-2">
                <img src={mulhimLogo} alt="Mulhim logo" className="w-8 h-8 object-contain" />
                <span className="text-[18px] font-black tracking-tight text-[#0F172A]">Mulhim</span>
              </div>
              <p className="text-[11.5px] text-slate-500 leading-relaxed">
                AI-powered coaching infrastructure for wellness and athletic preparation.
              </p>
              <div className="flex items-center gap-3 pt-1 text-slate-700">
                <IconX size={16} className="cursor-pointer hover:text-[#0F5B4E] transition-colors" />
                <IconInstagram size={16} className="cursor-pointer hover:text-[#0F5B4E] transition-colors" />
                <IconWhatsapp size={16} className="cursor-pointer hover:text-[#0F5B4E] transition-colors" />
              </div>
            </div>

            <div className="space-y-2">
              <p className="text-[12.5px] font-extrabold text-slate-900">Platform</p>
              <div className="flex flex-col space-y-1.5 text-[12px] text-slate-600 font-medium">
                <a href="#" onClick={(e) => e.preventDefault()} className="hover:text-[#0F5B4E]">For Coaches</a>
                <a href="#" onClick={(e) => e.preventDefault()} className="hover:text-[#0F5B4E]">For Organizations</a>
                <a href="#" onClick={(e) => e.preventDefault()} className="hover:text-[#0F5B4E]">Bioinformatics</a>
                <a href="#" onClick={(e) => e.preventDefault()} className="hover:text-[#0F5B4E]">Demo</a>
              </div>
            </div>

            <div className="space-y-2">
              <p className="text-[12.5px] font-extrabold text-slate-900">Company</p>
              <div className="flex flex-col space-y-1.5 text-[12px] text-slate-600 font-medium">
                <a href="#" onClick={(e) => e.preventDefault()} className="hover:text-[#0F5B4E]">About</a>
                <a href="#" onClick={(e) => e.preventDefault()} className="hover:text-[#0F5B4E]">Products</a>
                <a href="#" onClick={(e) => e.preventDefault()} className="hover:text-[#0F5B4E]">Privacy</a>
                <a href="#" onClick={(e) => e.preventDefault()} className="hover:text-[#0F5B4E]">Terms</a>
              </div>
            </div>

            <div className="space-y-2">
              <p className="text-[12.5px] font-extrabold text-slate-900">Resources</p>
              <div className="flex flex-col space-y-1.5 text-[12px] text-slate-600 font-medium">
                <a href="#" onClick={(e) => e.preventDefault()} className="hover:text-[#0F5B4E]">Docs</a>
                <a href="#" onClick={(e) => e.preventDefault()} className="hover:text-[#0F5B4E]">Support</a>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-200 flex items-center justify-between">
            <p className="text-[11.5px] text-slate-600 font-medium">
              © 2026 Mulhim Coach. All rights reserved.
            </p>
            <a
              href="#"
              onClick={(e) => e.preventDefault()}
              className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-black text-white rounded-xl shadow-sm active:scale-95 transition-transform"
            >
              <span className="text-sm leading-none"></span>
              <div className="text-left">
                <p className="text-[7px] uppercase font-semibold text-slate-400 leading-none">Download on the</p>
                <p className="text-[10.5px] font-bold leading-tight">App Store</p>
              </div>
            </a>
          </div>
        </footer>

      </div>
    </div>
  );
}

// ─── 2. Package Details Screen ────────────────────────────────────────────────
function PackageDetailsScreen({
  pkg,
  onBack,
  onProceed,
}: {
  pkg: PackageItem;
  onBack: () => void;
  onProceed: () => void;
}) {
  const [modalOpen, setModalOpen] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  return (
    <div className="flex flex-col h-full overflow-hidden bg-[#F8FAFC] relative">
      {/* Enterprise Contact Modal Form */}
      {modalOpen && (
        <div className="absolute inset-0 z-50 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-6">
          <div className="w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl space-y-4 animate-fadeIn">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-[16px] font-black text-[#0F172A]">Enterprise Roster Inquiry</h3>
              <button 
                onClick={() => { setModalOpen(false); setSubmitted(false); }}
                className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 hover:bg-slate-200"
              >
                ✕
              </button>
            </div>

            {submitted ? (
              <div className="py-8 text-center space-y-3">
                <div className="w-12 h-12 bg-emerald-100 text-[#0F5B4E] rounded-full flex items-center justify-center mx-auto font-bold text-lg">✓</div>
                <h4 className="text-[17px] font-extrabold text-slate-900">Inquiry Received!</h4>
                <p className="text-[12.5px] text-slate-600">Our institutional partnerships team will contact you within 24 hours.</p>
                <button
                  onClick={() => { setModalOpen(false); setSubmitted(false); }}
                  className="w-full py-3 rounded-xl bg-[#133E3E] text-white font-bold text-[13px] mt-4"
                >
                  Close Window
                </button>
              </div>
            ) : (
              <form onSubmit={(e) => { e.preventDefault(); setSubmitted(true); }} className="space-y-3">
                <div>
                  <label className="text-[11px] font-bold text-slate-700 block mb-1">Official Name (Manager / Lead)</label>
                  <input type="text" required placeholder="Dr. Tariq Al-Mansoor" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-[13px] outline-none" />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-slate-700 block mb-1">Organization / Club / Academy</label>
                  <input type="text" required placeholder="Al-Qadsiah Sports Club" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-[13px] outline-none" />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-slate-700 block mb-1">Institutional Email</label>
                  <input type="email" required placeholder="tariq@club.sa" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-[13px] outline-none" />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-slate-700 block mb-1">Mobile / Direct Phone</label>
                  <input type="tel" required placeholder="+966 50 000 0000" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-[13px] outline-none" />
                </div>
                <button
                  type="submit"
                  className="w-full py-3.5 rounded-xl bg-[#133E3E] text-white font-bold text-[13.5px] shadow-md mt-2 active:scale-95 transition-all"
                >
                  Submit Enterprise Inquiry
                </button>
              </form>
            )}
          </div>
        </div>
      )}

      <header className="flex items-center justify-between px-5 pt-3 pb-3 shrink-0 bg-white border-b border-slate-200">
        <button onClick={onBack} className="w-10 h-10 rounded-2xl flex items-center justify-center bg-slate-50 border border-slate-200">
          <IconArrowLeft size={18} color="#133E3E" />
        </button>
        <h1 className="text-[16px] font-extrabold text-[#0F172A]">Package Details</h1>
        <div className="w-9 h-9" />
      </header>

      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
        <div className="bg-white rounded-3xl overflow-hidden border border-slate-200 shadow-sm">
          <div className="relative h-44 w-full bg-slate-100">
            <img src={pkg.heroImage} alt={pkg.title} className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
            <span className="absolute bottom-3 left-4 text-[11px] font-bold uppercase text-[#A7F3D0]">{pkg.tag}</span>
          </div>
          <div className="p-5 space-y-2">
            <h2 className="text-[19px] font-extrabold text-[#0F172A]">{pkg.title}</h2>
            <p className="text-[12.5px] text-slate-600 leading-relaxed font-medium">{pkg.description}</p>
          </div>
        </div>

        <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm space-y-2">
          <h3 className="text-[13.5px] font-bold text-[#0F5B4E] uppercase tracking-wider">🎯 Goal of this Package</h3>
          <p className="text-[12.5px] text-slate-700 leading-relaxed font-medium">{pkg.goal}</p>
        </div>

        <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm space-y-3">
          <h3 className="text-[14px] font-bold text-[#0F172A] flex items-center gap-2">
            <IconHeartPulse size={16} color="#133E3E" />
            What You'll Discover
          </h3>
          <div className="space-y-2">
            {pkg.whatYouDiscover.map((item) => (
              <div key={item} className="p-3 bg-slate-50 border border-slate-100 rounded-xl text-[12px] font-medium text-slate-700 flex items-start gap-2.5">
                <IconCheck size={15} color="#10B981" className="shrink-0 mt-0.5" />
                <span>{item}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm space-y-3">
          <h3 className="text-[14px] font-bold text-[#0F172A] flex items-center gap-2">
            <IconClipboard size={16} color="#133E3E" />
            What You'll Receive in Mulhim
          </h3>
          <div className="space-y-2">
            {pkg.whatYouReceive.map((item) => (
              <div key={item} className="p-3 bg-[#E6F7F2]/40 border border-[#A7F3D0]/60 rounded-xl text-[12px] font-medium text-[#0F5B4E] flex items-start gap-2.5">
                <IconCheck size={15} color="#0F5B4E" className="shrink-0 mt-0.5" />
                <span>{item}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="p-4 bg-white border-t border-slate-200 shrink-0">
        {pkg.isEnterprise ? (
          <button
            onClick={() => setModalOpen(true)}
            className="w-full py-4 rounded-2xl font-bold bg-[#133E3E] text-white flex items-center justify-center gap-2 shadow-lg active:scale-[0.98]"
          >
            To learn more communicate with Us! →
          </button>
        ) : (
          <button
            onClick={onProceed}
            className="w-full py-4 rounded-2xl font-bold bg-[#133E3E] text-white flex items-center justify-center gap-2 shadow-lg active:scale-[0.98]"
          >
            Request At-Home Kit
            <IconChevronRight size={18} color="#A7F3D0" />
          </button>
        )}
      </div>
    </div>
  );
}

// ─── 3. Full 4-Step Checkout Screen ──────────────────────────────────────────
function CheckoutScreen({
  pkg,
  onBack,
  onComplete,
}: {
  pkg: PackageItem;
  onBack: () => void;
  onComplete: () => void;
}) {
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);
  const [agreed, setAgreed] = useState(false);
  const [payMethod, setPayMethod] = useState<"card" | "tamara" | "apple">("card");

  return (
    <div className="flex flex-col h-full overflow-hidden bg-[#F8FAFC]">
      <header className="flex items-center justify-between px-5 pt-3 pb-2 shrink-0 bg-white border-b border-slate-200">
        <button
          onClick={() => (step === 1 ? onBack() : setStep((s) => (s - 1) as any))}
          className="w-10 h-10 rounded-2xl flex items-center justify-center bg-slate-50 border border-slate-200"
        >
          <IconArrowLeft size={18} color="#133E3E" />
        </button>
        <h1 className="text-[16px] font-extrabold text-[#0F172A]">Order Checkout</h1>
        <div className="w-9 h-9" />
      </header>

      <div className="px-6 py-2.5 bg-white border-b border-slate-100 shrink-0">
        <div className="flex items-center justify-between mb-2">
          {["Details", "Consent", "Method", "Pay"].map((lbl, idx) => (
            <div key={lbl} className="flex flex-col items-center">
              <div
                className={`w-7 h-7 rounded-full flex items-center justify-center text-[11px] font-bold transition-all ${
                  step > idx + 1
                    ? "bg-[#10B981] text-white"
                    : step === idx + 1
                    ? "bg-[#133E3E] text-white ring-2 ring-[#A7F3D0]"
                    : "bg-slate-100 text-slate-400 border border-slate-200"
                }`}
              >
                {step > idx + 1 ? "✓" : idx + 1}
              </div>
              <span className={`text-[10px] mt-1 font-semibold ${step === idx + 1 ? "text-[#133E3E] font-bold" : "text-slate-400"}`}>
                {lbl}
              </span>
            </div>
          ))}
        </div>
        <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
          <div className="bg-[#133E3E] h-full transition-all duration-300" style={{ width: `${(step / 4) * 100}%` }} />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-5 py-4">
        {step === 1 && (
          <div className="space-y-4">
            <h2 className="text-[16px] font-extrabold text-[#0F172A]">Personal &amp; Shipping Info</h2>
            
            <div className="space-y-3">
              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">Full Name</label>
                <input 
                  type="text" 
                  placeholder="Faisal Al-Otaibi" 
                  className="w-full p-3 bg-white border border-slate-200 rounded-xl text-[13px] outline-none focus:border-[#133E3E]" 
                />
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="text-[11px] font-bold text-slate-700 block mb-1">Gender</label>
                  <select className="w-full p-3 bg-white border border-slate-200 rounded-xl text-[13px] outline-none focus:border-[#133E3E]">
                    <option>Male</option>
                    <option>Female</option>
                  </select>
                </div>
                <div>
                  <label className="text-[11px] font-bold text-slate-700 block mb-1">Height</label>
                  <input 
                    type="number" 
                    placeholder="Enter height" 
                    className="w-full p-3 bg-white border border-slate-200 rounded-xl text-[13px] outline-none focus:border-[#133E3E]" 
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="text-[11px] font-bold text-slate-700 block mb-1">Birth Date</label>
                  <input 
                    type="date" 
                    className="w-full p-3 bg-white border border-slate-200 rounded-xl text-[13px] outline-none focus:border-[#133E3E]" 
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-slate-700 block mb-1">Weight</label>
                  <input 
                    type="number" 
                    placeholder="Enter weight" 
                    className="w-full p-3 bg-white border border-slate-200 rounded-xl text-[13px] outline-none focus:border-[#133E3E]" 
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">Delivery City &amp; Address</label>
                <input 
                  type="text" 
                  placeholder="Riyadh, Al Nakheel District, Street 14" 
                  className="w-full p-3 bg-white border border-slate-200 rounded-xl text-[13px] outline-none focus:border-[#133E3E]" 
                />
              </div>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-4">
            <h2 className="text-[16px] font-extrabold text-[#0F172A]">Bioinformatic Consent Form</h2>
            
            <div className="bg-white border border-slate-200 rounded-2xl p-4 text-[12px] text-slate-600 space-y-3.5 max-h-72 overflow-y-auto leading-relaxed shadow-sm">
              <div className="space-y-1">
                <p className="font-bold text-slate-800 text-[12.5px]">1. Purpose of Biological Analysis</p>
                <p>Your sample is processed exclusively to deliver customized fitness, recovery, and metabolic nutrition guidance inside the Mulhim platform. The generated insights serve wellness and performance optimization purposes.</p>
              </div>

              <div className="space-y-1">
                <p className="font-bold text-slate-800 text-[12.5px]">2. Privacy Isolation &amp; Data Security</p>
                <p>All raw biological markers and personal health telemetry are fully encrypted end-to-end (AES-256). Your data will never be shared, rented, or sold to health insurance agencies, third-party advertisers, or external marketing networks.</p>
              </div>

              <div className="space-y-1">
                <p className="font-bold text-slate-800 text-[12.5px]">3. Sample Processing &amp; Laboratory Safety</p>
                <p>Biological samples are sequenced in certified, clinical-grade accredited laboratories adhering to strict international quality standards. Samples are securely decommissioned following successful data digitization.</p>
              </div>

              <div className="space-y-1">
                <p className="font-bold text-slate-800 text-[12.5px]">4. AI Model Calibration &amp; Dynamic Insights</p>
                <p>Anonymized biological scores are mapped to Mulhim's adaptive algorithms to continuously calibrate your workout volume, macronutrient targets, and resting heart rate recovery zones based on your daily inputs.</p>
              </div>

              <div className="space-y-1">
                <p className="font-bold text-slate-800 text-[12.5px]">5. Voluntary Participation &amp; Data Ownership</p>
                <p>Participation is completely voluntary. You maintain full ownership over your profile and reserve the right to request permanent deletion of your biological records at any time from your account settings.</p>
              </div>
            </div>

            <label className="flex items-start gap-3 p-4 bg-[#E6F7F2] border border-[#A7F3D0] rounded-2xl cursor-pointer hover:bg-[#dcf4ed] transition-colors">
              <input 
                type="checkbox" 
                checked={agreed} 
                onChange={(e) => setAgreed(e.target.checked)} 
                className="mt-0.5 w-4 h-4 rounded border-slate-300 text-[#133E3E] focus:ring-[#133E3E] accent-[#133E3E]" 
              />
              <span className="text-[12px] font-semibold text-[#0F5B4E] leading-snug">
                I have read and agree to the comprehensive biological analysis, data security, and privacy terms.
              </span>
            </label>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-4">
            <h2 className="text-[16px] font-extrabold text-[#0F172A]">Payment Method</h2>
            <div className="bg-white border border-slate-200 rounded-2xl p-4 flex items-center justify-between shadow-sm">
              <div>
                <p className="text-[13px] font-bold text-[#0F172A]">{pkg.title}</p>
                <p className="text-[11px] text-slate-500">At-home swab kit + AI coaching protocol</p>
              </div>
              <span className="text-[11px] font-extrabold text-[#0F5B4E] bg-[#E6F7F2] px-2.5 py-1 rounded-md">
                Included
              </span>
            </div>
            <div className="space-y-2.5">
              {[
                { id: "card", label: "Credit / Mada Card" },
                { id: "tamara", label: "Split with Tamara" },
                { id: "tabby", label: "Split with Tabby" },
                { id: "apple", label: "Apple Pay" },
              ].map((m) => (
                <div
                  key={m.id}
                  onClick={() => setPayMethod(m.id as any)}
                  className={`p-4 bg-white border rounded-2xl flex items-center justify-between cursor-pointer transition-all ${
                    payMethod === m.id ? "border-[#133E3E] ring-2 ring-[#133E3E]/10" : "border-slate-200"
                  }`}
                >
                  <span className="text-[13px] font-bold text-slate-800">{m.label}</span>
                  <div className={`w-5 h-5 rounded-full border flex items-center justify-center ${payMethod === m.id ? "bg-[#133E3E] border-[#133E3E]" : "border-slate-300"}`}>
                    {payMethod === m.id && <div className="w-2 h-2 rounded-full bg-white" />}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {step === 4 && (
          <div className="space-y-4">
            <h2 className="text-[16px] font-extrabold text-[#0F172A]">Payment Gateway</h2>
            {payMethod === "card" ? (
              <div className="space-y-3">
                <div>
                  <label className="text-[11px] font-bold text-slate-700 block mb-1">Cardholder Name</label>
                  <input type="text" placeholder="Faisal Al-Otaibi" className="w-full p-3 bg-white border border-slate-200 rounded-xl text-[13px] outline-none" />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-slate-700 block mb-1">Card Number</label>
                  <input type="text" placeholder="4111 •••• •••• ••••" className="w-full p-3 bg-white border border-slate-200 rounded-xl text-[13px] outline-none" />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[11px] font-bold text-slate-700 block mb-1">MM/YY</label>
                    <input type="text" placeholder="08/28" className="w-full p-3 bg-white border border-slate-200 rounded-xl text-[13px] outline-none" />
                  </div>
                  <div>
                    <label className="text-[11px] font-bold text-slate-700 block mb-1">CVV</label>
                    <input type="password" placeholder="•••" className="w-full p-3 bg-white border border-slate-200 rounded-xl text-[13px] outline-none" />
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-8 bg-white border border-slate-200 rounded-3xl text-center text-xs text-slate-500 space-y-2">
                <p className="font-bold text-slate-800 text-[14px]">Redirecting securely...</p>
                <p>Click below to complete transaction.</p>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="p-4 bg-white border-t border-slate-200 shrink-0">
        <button
          disabled={step === 2 && !agreed}
          onClick={() => { if (step < 4) setStep((s) => (s + 1) as any); else onComplete(); }}
          className={`w-full py-4 rounded-2xl font-bold flex items-center justify-center gap-2 shadow-md active:scale-95 transition-all ${
            step === 2 && !agreed ? "bg-slate-200 text-slate-400" : "bg-[#094848] text-white"
          }`}
        >
          {step === 4 ? "Complete Order" : "Continue Next Step"}
          <IconChevronRight size={18} color="#A7F3D0" />
        </button>
      </div>
    </div>
  );
}

// ─── 4. Order Confirmation Screen ─────────────────────────────────────────────
function ConfirmationScreen({
  onStartQuestionnaire,
  onReset,
}: {
  onStartQuestionnaire: () => void;
  onReset: () => void;
}) {
  return (
    <div className="flex flex-col h-full items-center justify-between p-6 text-center overflow-y-auto bg-white">
      <div className="w-full pt-8 flex flex-col items-center">
        <div className="w-16 h-16 rounded-full bg-[#E6F7F2] border border-[#A7F3D0] flex items-center justify-center mb-4 shadow-sm">
          <IconCheck size={28} color="#0F5B4E" />
        </div>
        <span className="text-[10px] font-bold text-[#0F5B4E] bg-[#E6F7F2] px-3 py-1 rounded-full mb-3">Order Confirmed #ML-8841</span>
        <h2 className="text-[22px] font-extrabold text-[#0F172A] mb-1">Your DNA Kit is Dispatched!</h2>
        <p className="text-[13px] text-slate-500 max-w-[260px] mb-5">Delivery confirmation and tracking details have been sent to your email.</p>
        <div className="w-full bg-slate-50 border border-slate-200 rounded-2xl p-4 text-left shadow-sm space-y-1">
          <p className="text-[13px] font-bold text-[#0F172A]">🎯 Immediate Next Step:</p>
          <p className="text-[12px] text-slate-600 leading-relaxed">Fill out your phenotype lifestyle log while your physical swab kit is in transit.</p>
        </div>
      </div>

      <div className="w-full space-y-2.5 pb-4 shrink-0 mt-4">
        <button onClick={onStartQuestionnaire} className="w-full py-4 rounded-2xl font-bold bg-[#133E3E] text-white flex items-center justify-center gap-2 shadow-md">
          Start Phenotype Log Now <IconChevronRight size={18} color="#A7F3D0" />
        </button>
        <button onClick={onReset} className="text-[12px] font-semibold text-slate-400">Back to Landing Page</button>
      </div>
    </div>
  );
}

// ─── 5. Updated Questionnaire Screen ──────────────────────────────────────────
function QuestionnaireScreen({ onFinished }: { onFinished: () => void }) {
  const [currentStep, setCurrentStep] = useState(1);
  const totalSteps = 5;

  return (
    <div className="flex flex-col h-full overflow-hidden bg-[#F8FAFC]">
      <header className="flex items-center justify-between px-5 pt-3 pb-3 shrink-0 bg-white border-b border-slate-200">
        <button
          onClick={() => currentStep > 1 && setCurrentStep(currentStep - 1)}
          disabled={currentStep === 1}
          className={`w-10 h-10 rounded-2xl flex items-center justify-center bg-slate-50 border border-slate-200 ${currentStep === 1 ? "opacity-30" : ""}`}
        >
          <IconArrowLeft size={18} color="#133E3E" />
        </button>
        <h1 className="text-[16px] font-extrabold text-[#0F172A]">Phenotype Data Log</h1>
        <div className="w-9 h-9" />
      </header>

      <div className="px-6 py-3 shrink-0 bg-white border-b border-slate-100">
        <div className="flex justify-between items-center mb-1.5">
          <span className="text-[11px] font-bold text-[#133E3E] uppercase tracking-wider">STEP {currentStep} OF {totalSteps}</span>
          <span className="text-[12px] font-extrabold text-slate-700">{Math.round((currentStep / totalSteps) * 100)}%</span>
        </div>
        <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
          <div className="bg-[#133E3E] h-full transition-all duration-300" style={{ width: `${(currentStep / totalSteps) * 100}%` }} />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-4">
        {/* Step 1 */}
        {currentStep === 1 && (
          <div className="space-y-4">
            <div className="w-12 h-12 bg-red-50 rounded-2xl flex items-center justify-center mb-2">
              <IconHeartPulse size={24} color="#EF4444" />
            </div>
            <h2 className="text-[20px] font-extrabold text-[#0F172A]">Blood Pressure Profile</h2>
            <p className="text-[13px] text-slate-500">Provide your latest pressure reading if known.</p>
            <div className="space-y-3 pt-2">
              <div>
                <label className="text-[12px] font-bold text-slate-700 block mb-1">Systolic BP (mmHg)</label>
                <input type="number" placeholder="120" className="w-full p-3.5 bg-white border border-slate-200 rounded-xl text-[14px] outline-none focus:border-[#133E3E]" />
              </div>
              <div>
                <label className="text-[12px] font-bold text-slate-700 block mb-1">Diastolic BP (mmHg)</label>
                <input type="number" placeholder="80" className="w-full p-3.5 bg-white border border-slate-200 rounded-xl text-[14px] outline-none focus:border-[#133E3E]" />
              </div>
            </div>
          </div>
        )}

        {/* Step 2 */}
        {currentStep === 2 && (
          <div className="space-y-4">
            <div className="w-12 h-12 bg-cyan-50 rounded-2xl flex items-center justify-center mb-2">
              <IconDroplet size={24} color="#06B6D4" />
            </div>
            <h2 className="text-[20px] font-extrabold text-[#0F172A]">Daily Hydration Level</h2>
            <p className="text-[13px] text-slate-500">Average water and electrolyte intake per day.</p>
            <div className="space-y-2 pt-2">
              {[
                { title: "Less than 1.5 Liters", desc: "Low hydration, occasional fatigue" },
                { title: "1.5L – 2.5 Liters", desc: "Optimal baseline hydration" },
                { title: "2.5L – 3.5+ Liters", desc: "High hydration, active athletic fueling" },
              ].map((item) => (
                <div
                  key={item.title}
                  onClick={() => setCurrentStep(3)}
                  className="p-4 bg-white border border-slate-200 rounded-2xl cursor-pointer hover:border-[#133E3E] active:bg-[#E6F7F2]/40 transition-colors"
                >
                  <p className="text-[14px] font-bold text-slate-800">{item.title}</p>
                  <p className="text-[12px] text-slate-500">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Step 3 */}
        {currentStep === 3 && (
          <div className="space-y-4">
            <div className="w-12 h-12 bg-orange-50 rounded-2xl flex items-center justify-center mb-2">
              <IconHeart size={24} color="#F97316" />
            </div>
            <h2 className="text-[20px] font-extrabold text-[#0F172A]">Resting Heart Rate (RHR)</h2>
            <p className="text-[13px] text-slate-500">Your average morning pulse rate from your smartwatch.</p>
            <div className="pt-2">
              <label className="text-[12px] font-bold text-slate-700 block mb-1">Beats Per Minute (BPM)</label>
              <input type="number" placeholder="62" className="w-full p-3.5 bg-white border border-slate-200 rounded-xl text-[14px] outline-none focus:border-[#133E3E]" />
            </div>
          </div>
        )}

        {/* Step 4 */}
        {currentStep === 4 && (
          <div className="space-y-4">
            <div className="w-12 h-12 bg-purple-50 rounded-2xl flex items-center justify-center mb-2">
              <IconMoon size={24} color="#A855F7" />
            </div>
            <h2 className="text-[20px] font-extrabold text-[#0F172A]">Sleep Architecture</h2>
            <p className="text-[13px] text-slate-500">Average nocturnal restful sleep duration.</p>
            <div className="grid grid-cols-2 gap-2 pt-2">
              {["Less than 6h", "6h - 7h", "7h - 9h", "9h+"].map((option) => (
                <button key={option} onClick={() => setCurrentStep(5)} className="p-4 bg-white border border-slate-200 rounded-xl text-[13px] font-semibold text-left text-slate-700 hover:border-[#133E3E]">
                  {option}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Step 5 */}
        {currentStep === 5 && (
          <div className="space-y-4">
            <div className="w-12 h-12 bg-emerald-50 rounded-2xl flex items-center justify-center mb-2">
              <IconDumbbell size={24} color="#10B981" />
            </div>
            <h2 className="text-[20px] font-extrabold text-[#0F172A]">Weekly Activity Level</h2>
            <p className="text-[13px] text-slate-500">Select your current physical workout load.</p>
            <div className="space-y-2 pt-2">
              {[
                { title: "Sedentary", desc: "Desk job, minimal structured exercise" },
                { title: "Moderately Active", desc: "3-4 direct training sessions a week" },
                { title: "Athletic Pro", desc: "Daily intense training and match load" },
              ].map((item) => (
                <div key={item.title} onClick={onFinished} className="p-4 bg-white border border-slate-200 rounded-2xl cursor-pointer hover:border-[#133E3E] active:bg-[#E6F7F2]/40 transition-colors">
                  <p className="text-[14px] font-bold text-slate-800">{item.title}</p>
                  <p className="text-[12px] text-slate-500">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="p-4 bg-white border-t border-slate-200 shrink-0">
        {currentStep < 5 ? (
          <button
            onClick={() => setCurrentStep(currentStep + 1)}
            className="w-full py-4 rounded-2xl font-bold bg-[#094848] text-white flex items-center justify-center gap-2 shadow-md active:scale-95 transition-all"
          >
            Next Metric <IconChevronRight size={18} color="#A7F3D0" />
          </button>
        ) : (
          <button
            onClick={onFinished}
            className="w-full py-4 rounded-2xl font-bold bg-[#10B981] hover:bg-[#059669] text-white flex items-center justify-center gap-2 shadow-md active:scale-95 transition-all"
          >
            Submit &amp; Proceed to App Download <IconCheck size={18} />
          </button>
        )}
      </div>
    </div>
  );
}

// ─── 6. Standalone App Download Screen ────────────────────────────────────────
function AppDownloadScreen({ onReset }: { onReset: () => void }) {
  return (
    <div className="flex flex-col h-full overflow-hidden bg-[#F8FAFC]">
      <header className="flex items-center justify-between px-5 pt-3 pb-3 shrink-0 bg-white border-b border-slate-200">
        <h1 className="text-[16px] font-extrabold text-[#0F172A] text-center w-full">Download Mulhim App</h1>
      </header>

      <div className="flex-1 overflow-y-auto p-6 text-center flex flex-col items-center justify-between">
        <div className="w-full pt-4 flex flex-col items-center">
          <div className="w-16 h-16 rounded-full bg-[#E6F7F2] border border-[#A7F3D0] flex items-center justify-center mb-4 relative">
            <div className="w-12 h-12 bg-[#133E3E] rounded-2xl flex items-center justify-center shadow-md">
              <IconCheck size={24} color="#A7F3D0" />
            </div>
            <div className="absolute -top-1 -right-1 w-5 h-5 bg-[#10B981] text-white text-[10px] font-bold rounded-full flex items-center justify-center">
              ✓
            </div>
          </div>

          <h2 className="text-[24px] font-extrabold text-[#133E3E] tracking-tight mb-1">Kit Dispatched &amp; Profile Synced!</h2>
          <p className="text-[13px] text-slate-600 max-w-[280px] leading-relaxed mb-6 font-medium">
            Your at-home swab kit is on its way. Download the Mulhim App to track your sample and receive your real-time biological plan.
          </p>

          <div className="w-full bg-white border border-slate-200 rounded-3xl p-5 text-center shadow-sm space-y-3">
            <p className="text-[13px] font-bold text-slate-900">
              Download Mulhim to unlock your personalized plan:
            </p>

            <div className="space-y-2.5 pt-1">
              <a
                href="#"
                onClick={(e) => e.preventDefault()}
                className="flex items-center justify-center gap-3 w-full py-3 bg-black text-white rounded-xl active:scale-[0.99] shadow-sm"
              >
                <span className="text-xl"></span>
                <div className="text-left">
                  <p className="text-[9px] uppercase font-semibold text-slate-400 leading-none">Download on the</p>
                  <p className="text-[14px] font-bold leading-tight">App Store</p>
                </div>
              </a>
              <a
                href="#"
                onClick={(e) => e.preventDefault()}
                className="flex items-center justify-center gap-3 w-full py-3 bg-white text-white rounded-xl active:scale-[0.99] shadow-sm"
              >
                <div className="w-4 h-4 bg-gradient-to-r from-blue-500 via-red-500 to-yellow-500 rounded-sm shrink-0" />
                <div className="text-left">
                  <p className="text-[9px] uppercase font-semibold text-slate-400 leading-none">Get it on</p>
                  <p className="text-[14px] font-bold leading-tight">Google Play</p>
                </div>
              </a>
            </div>
          </div>
        </div>

        <div className="w-full pb-4 shrink-0 mt-6">
          <button
            onClick={onReset}
            className="w-full py-4 rounded-2xl font-bold border border-slate-200 bg-white text-slate-700 shadow-sm active:scale-95 hover:bg-slate-50"
          >
            Return to Bioinformatics Home
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Root App ─────────────────────────────────────────────────────────────────
export default function App() {
  const [screen, setScreen] = useState<Screen>("landing");
  const [selectedPkg, setSelectedPkg] = useState<PackageItem>(PACKAGES[0]);

  return (
    <>
      <style>{GLOBAL_STYLES}</style>
      <div
        className="min-h-screen flex items-center justify-center py-6"
        style={{
          background: "linear-gradient(135deg, #D1FAE5 0%, #E0F2FE 50%, #F0FDF4 100%)",
          fontFamily: "'Plus Jakarta Sans', sans-serif",
        }}
      >
        <div
          className="relative bg-white overflow-hidden flex flex-col shadow-2xl"
          style={{
            width: 834,
            height: 1194,
            borderRadius: 36,
            boxShadow: "0 0 0 10px #0F172A, 0 32px 80px rgba(19,62,62,0.35), 0 8px 24px rgba(0,0,0,0.2)",
          }}
        >
          <StatusBar />

          <div className="flex-1 overflow-hidden relative flex flex-col">
            {screen === "landing" && (
              <BioinformaticsLandingScreen
                onSelectPackage={(pkg) => {
                  setSelectedPkg(pkg);
                  setScreen("details");
                }}
              />
            )}

            {screen === "details" && (
              <PackageDetailsScreen
                pkg={selectedPkg}
                onBack={() => setScreen("landing")}
                onProceed={() => setScreen("checkout")}
              />
            )}

            {screen === "checkout" && (
              <CheckoutScreen
                pkg={selectedPkg}
                onBack={() => setScreen("details")}
                onComplete={() => setScreen("confirmation")}
              />
            )}

            {screen === "confirmation" - screen === "confirmation" && (
              <ConfirmationScreen
                onStartQuestionnaire={() => setScreen("questionnaire")}
                onReset={() => setScreen("landing")}
              />
            )}

            {screen === "questionnaire" && (
              <QuestionnaireScreen
                onFinished={() => setScreen("appdownload")}
              />
            )}

            {screen === "appdownload" && (
              <AppDownloadScreen
                onReset={() => setScreen("landing")}
              />
            )}
          </div>
        </div>
      </div>
    </>
  );
}